export const redirectToDashboard = (role) => {
  if (role === 'seller') {
    window.location.href = '/seller-dashboard';
  } else if (role === 'buyer') {
    window.location.href = '/buyer-dashboard';
  }
};