import { getFirestore, doc, setDoc } from 'firebase/firestore';

const db = getFirestore();

export const createUserProfile = async (uid, fullName, phoneNumber, role) => {
  await setDoc(doc(db, 'users', uid), {
    fullName,
    phoneNumber,
    role,
    isVerified: false,
  });
};