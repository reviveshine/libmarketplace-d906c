import React, { useState } from 'react';
import { handleRegister } from '../handleRegister';
import { ROLES } from '../roleConstants';

const RegisterForm = () => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [password, setPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState(ROLES.BUYER);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    handleRegister(email, password, fullName, phoneNumber, selectedRole, setIsSubmitting);
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Create Account</h2>
      <input type="text" placeholder="Full Name" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
      <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
      <input type="tel" placeholder="Phone Number" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} required />
      <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />

      <select value={selectedRole} onChange={(e) => setSelectedRole(e.target.value)}>
        <option value={ROLES.BUYER}>Buyer</option>
        <option value={ROLES.SELLER}>Seller</option>
      </select>

      <button type="submit" disabled={isSubmitting}>
        {isSubmitting ? 'Creating Account...' : 'Sign Up'}
      </button>
    </form>
  );
};

export default RegisterForm;