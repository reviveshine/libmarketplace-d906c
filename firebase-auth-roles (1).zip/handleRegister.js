import { registerUser } from './authService';
import { createUserProfile } from './userService';
import { ROLES } from './roleConstants';
import { redirectToDashboard } from './navigationUtils';

export const handleRegister = async (email, password, fullName, phoneNumber, selectedRole, setIsSubmitting) => {
  setIsSubmitting(true);
  try {
    const { user } = await registerUser(email, password);
    await createUserProfile(user.uid, fullName, phoneNumber, selectedRole);
    redirectToDashboard(selectedRole);
  } catch (error) {
    switch (error.code) {
      case 'auth/email-already-in-use':
        alert('Email is already in use.');
        break;
      case 'auth/weak-password':
        alert('Password is too weak. Please use at least 6 characters.');
        break;
      case 'auth/invalid-email':
        alert('Invalid email address.');
        break;
      default:
        alert('Registration failed. Please try again.');
    }
  } finally {
    setIsSubmitting(false);
  }
};